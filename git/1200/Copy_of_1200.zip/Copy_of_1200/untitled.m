clear all
global n b jifenk Ck Cp Cf Tk Tp Tf
global N h up uf
h=792;
n=6027.639;b=2.196;
N=4;
up=432;
Ck=25; Cp=100; Cf=1500;
Tk=0.2; Tp=4; Tf=8;
uf=100;
% jifenk=1000;
% k=1000;
% integral(@test,0,pi)
% E(h,k)
obj1(h,up)
obj2(h,up)
function [outputArg1] = Pfk(x1,x2)
outputArg1=1-R(x1)/R(x2);
end

